#!/bin/bash
for x in "papel dorado" "lapiz caro" "boligrafo barato"
do
  echo "El valor de la variable es $x"
  sleep 5
done
