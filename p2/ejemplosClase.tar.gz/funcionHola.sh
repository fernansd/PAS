#!/bin/bash
hola()
{
	echo "Estás dentro de la función hola() y te saludo."
}

echo "La próxima línea llama a la función hola()"
hola
echo "Ahora ya has salido de la funcion"
