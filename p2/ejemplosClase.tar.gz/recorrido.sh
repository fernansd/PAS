#!/bin/bash
for f in $(find "/home/pagutierrez/Escritorio/TOSHIBAHD/Docencia/curso 12-13/PAS/Guiones/Practica/practica1-Shell/ejemplos" -name "*.sh")
do
	echo "El fichero es $f"
done
